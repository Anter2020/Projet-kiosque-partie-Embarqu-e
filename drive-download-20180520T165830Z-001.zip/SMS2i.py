from xlwt import Workbook
import xlwt
import time
import datetime
import os
import snap7
from snap7.util import *
import struct
import threading
import xlrd
import random
import time
import serial
import sys

wb = xlwt.Workbook(encoding="utf-8")
wr = xlrd.open_workbook('xlmt SMS2i.xls')
wb=Workbook()
sheet={}
y=0

f = open("not.txt", "r")
i=int(f.readline())
f.close()
recipient = "+216*********"
##-------------------------------------------plc + erreur msg------------
def printit(start):
    try:
        area = 0x83
        plc = snap7.client.Client()
        plc.connect("169.254.181.47",0,1)
        #threading.Timer(1.0, printit(start)).start()
        byte = plc.read_area(area,0,start,2)
        plc.disconnect()
        return get_int(byte,0)
    
    except:
        print ('no open plc')
        try:
            ##---send msg commande at-----------
            msg ='alarme : no open plc'
            phone = serial.Serial("/dev/ttyAMA0",baudrate=9600, timeout=1)
            time.sleep(0.5)
            phone.write('AT'+'\r\n')
            time.sleep(0.5)
            phone.write('AT+CMGF=1'+'\r\n')
            time.sleep(0.5)
            phone.write(b'AT+CMGS="' + recipient.encode() + b'"\r')
            phone.write(msg.encode() + b"\r")
            time.sleep(0.5)
            phone.write("\x1A")
            phone.close()
            
        except:
            print ('erreur d envoi ')
    

##---------------------------------insert valeur in excel--------
def get_level_data(T):  
    start = 100    
    for j in range(1,15):      
        T[j]=printit(start)
        start = start + 2

        
def ouverture_page():
    for j in range(1,15):
        sheet[w]= wr.sheet_by_name('Tank '+str(w))
    wb.save('xlmt SMS2i.xls')
        
##----------------------if file exist or no 
if i==0:
    for w in range(1,15) :
        sheet[w]=wb.add_sheet('Tank '+str(w))
        print ('fichier non exist')
    wb.save('xlmt SMS2i.xls')
        
else :
    for w in range(1,15) :
        #sheet[i] = wr.sheet_by_index(i)
        sheet[w]= wr.sheet_by_name('Tank '+str(w))
        print ('fichier exist')
    print ('aaa')
    wb.save('xlmt SMS2i.xls')
    
##-------------- action de saisir les valeur 
print i
while True :
    print (datetime.datetime.now().strftime("%H:%M"))
    x=datetime.datetime.now().strftime("%H:%M")
    if i <1 or datetime.datetime.now().strftime("%H:%M") == '00:00' :
        print ('date today')
        t=datetime.date.today()
        for k in range(1,15):
            sheet[k].write(i,y,"Date : "+str(t))
            sheet[k].write(i,y+1,"Time")

        i=i+1
            
        f = open("not.txt", "w")
        f.writelines(str(i))
        print i
        f.close()
        wb.save('xlmt SMS2i.xls')
            
    elif i >= 1 and (int(datetime.datetime.now().strftime("%M"))% 2)==0 and datetime.datetime.now().strftime("%H:%M") != '00:00':
        print ('remplissage de niveau tank apres 30 min ')
        T= {}
        sheet={}
        get_level_data(T)
        ouverture_page()
        for k in range(1,15):
            sheet[k].write(i,y,T[k])
            sheet[k].write(i,y+1,x)
            #sheet[k].write(i,y,0)
        i=i+1
        f = open("not.txt", "w")
        f.writelines(str(i))
        print i
        f.close()
        time.sleep(61)
        wb.save('xlmt SMS2i.xls')
            
    if datetime.datetime.now().strftime("%H:%M") == '08:00'or datetime.datetime.now().strftime("%H:%M") == '20:00':
            phone = serial.Serial("/dev/ttyAMA0",baudrate=9600, timeout=1)

            print ('envoi d et')
            time.sleep(0.5)
            phone.write('AT'+'\r\n')
            time.sleep(0.5)
            phone.write('AT+CMGF=1'+'\r\n')
            time.sleep(0.5)
            phone.write(b'AT+CMGS="' + recipient.encode() + b'"\r')
            phone.write(msg.encode() + b"\r")
            time.sleep(0.5)
            phone.write("\x1A")
            phone.close()
          ##  except :
##            print ('erreur')
##            time.sleep(0.5)
##            phone.write('AT'+'\r\n')
##            time.sleep(0.5)
##            phone.write('AT+CMGF=1'+'\r\n')
##            time.sleep(0.5)
##            phone.write(b'AT+CMGS="' + recipient.encode() + b'"\r')
##            phone.write(msg.encode() + b"\r")
##            time.sleep(0.5)
##            phone.write("\x1A")
##            phone.close()
 ##   except :
##        print ('archiv')
##    if sheet 1 != wb.add_sheet('Tank 1'):
##            print ('erreur programme d archive ')
##            msg1='allarme : erreur programme d archive '
##
##            phone = serial.Serial("/dev/ttyAMA0",baudrate=9600, timeout=1)
##            time.sleep(0.5)
##            phone.write('AT'+'\r\n')
##            time.sleep(0.5)
##            phone.write('AT+CMGF=1'+'\r\n')
##            time.sleep(0.5)
##            phone.write(b'AT+CMGS="' + recipient.encode() + b'"\r')
##            phone.write(msg1.encode() + b"\r")
##            time.sleep(0.5)
##            phone.write("\x1A")
##            print ('fermeture du port ')
##            phone.close()
wb.save('xlmt SMS2i.xls')
f.close


